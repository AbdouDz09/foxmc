package me.rellynn.foxmc.gameapiv2.utils;

/**
 * Created by gwennaelguich on 28/05/2017.
 * FoxMC Network.
 */
public enum BroadcastType {
    TITLE,
    SUBTITLE,
    CHAT,
    PACKET,
    SOUND,
    ACTIONBAR
}
