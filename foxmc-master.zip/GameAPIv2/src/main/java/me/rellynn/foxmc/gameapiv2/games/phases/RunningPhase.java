package me.rellynn.foxmc.gameapiv2.games.phases;

import me.rellynn.foxmc.gameapiv2.games.GameState;

/**
 * Created by gwennaelguich on 28/05/2017.
 * FoxMC Network.
 */
public class RunningPhase extends Phase {

    public RunningPhase() {
        super(GameState.RUNNING);
    }
}
