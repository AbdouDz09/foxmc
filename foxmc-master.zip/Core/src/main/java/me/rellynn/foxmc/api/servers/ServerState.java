package me.rellynn.foxmc.api.servers;

/**
 * Created by gwennaelguich on 12/08/2017.
 * FoxMC Network.
 */
public enum ServerState {
    JOINABLE,
    NOT_JOINABLE,
    RESTARTING
}
