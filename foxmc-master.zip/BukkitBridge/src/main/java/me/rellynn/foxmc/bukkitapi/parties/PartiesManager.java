package me.rellynn.foxmc.bukkitapi.parties;

import me.rellynn.foxmc.api.parties.PartiesHandler;

/**
 * Created by gwennaelguich on 16/08/2017.
 * FoxMC Network.
 */
public class PartiesManager extends PartiesHandler {
}
