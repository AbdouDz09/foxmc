package me.rellynn.foxmc.hub.games.sbuilders;

import me.rellynn.foxmc.hub.main.game.GameMenu;

/**
 * Created by gwennaelguich on 21/08/2017.
 * FoxMC Network.
 */
public class SBuildersGameMenu extends GameMenu {

    public SBuildersGameMenu() {
        super("sbuilders", "SpeedBuilders");
        addQueueItem("default", "§bDefault");
    }
}
