package me.rellynn.foxmc.anticheat.listeners;

import me.rellynn.foxmc.api.anticheat.AntiCheatHandler;

/**
 * Created by gwennaelguich on 13/08/2017.
 * FoxMC Network.
 */
public class AntiCheatManager extends AntiCheatHandler {
}
